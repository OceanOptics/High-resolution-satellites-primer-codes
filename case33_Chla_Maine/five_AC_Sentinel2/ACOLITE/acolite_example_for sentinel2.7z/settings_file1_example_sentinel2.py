## Example settings for Zeebrugge with gains##
##Earth data 




EARTHDATA_u = Your ACCOUNT
EARTHDATA_p =  Your CODE



inputfile=/home/bjiang/Sentinel2/getOC-master-3/20162019DamCasco/orgintrytry/S2A_MSIL1C_20180505T153601_N0206_R111_T19TDJ_20180505T192748.SAFE     

output=/home/bjiang/Sentinel2/getOC-master-3/20162019DamCasco/acolitetrytry

ancillary_data = True
#result[i][0:-42]

limit=None
l2w_parameters=Rrs_443,Rrs_442, Rrs_492, Rrs_560, Rrs_559, Rrs_665,  Rrs_704,  Rrs_740,Rrs_739, Rrs_783,Rrs_780,  Rrs_865, Rrs_864, Rrs_833, Rrs_1614, Rrs_2202
## Apply the preliminary gains by Pahlevan et al. (2017)
gains=True
gains_s2a_msi=1,1,1,1,1,1,1,1,1,1,1,1,1
gains_s2b_msi=1,1,1,1,1,1,1,1,1,1,1,1,1
## output resolution (S2 only 10, 20, or 60 m)

s2_target_res=20
#dsf_path_reflectance=tiled
#dsf_tile_dims=100,100
# for test default 300,300 for 20m resolution  default 6km*6km

l2w_mask=True
l2w_mask_water_parameters=True
l2w_mask_threshold=0.05
l2w_mask_cirrus=True
#glint_correction=True

rgb_rhot=False
map_l2w=False
rgb_rhos=False
l1r_nc_delete=True
#Controls the deletion of the L1R NetCDF file. Options: True/False
l2r_nc_delete=True
#Controls the deletion of the L2R NetCDF file. Options: True/False
l2w_nc_delete=False
dsf_plot_retrieved_tiles=False
dsf_plot_dark_spectrum=False
#If you want to speed up the processing you can either change the tile size of the path reflectance retrieval (in output pixel sizes):
#dsf_path_reflectance=tiled
#dsf_tile_dims=1000,1000

#Alternatively you can disable the tiled processing (default as of Jan 2021), replace:
#dsf_path_reflectance=tiled
#by:
#dsf_path_reflectance=fixed
