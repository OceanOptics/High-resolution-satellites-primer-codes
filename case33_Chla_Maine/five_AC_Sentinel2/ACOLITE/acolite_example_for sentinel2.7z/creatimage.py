import os



#find the dir 
path = "/home/bjiang/bjiang_tmp_20210303/bowdoin2016-2021/orgin"    # creat your own txt for your files where are under sentinel2 files
#find the file name
filename = "xml"
#definte the result of find
result = []

def findfiles(files_path, files_list):
    #find the file code
    files = os.listdir(files_path)
    for s in files:
        s_path = os.path.join(files_path, s)
        if os.path.isdir(s_path):
            findfiles(s_path, files_list)
        elif os.path.isfile(s_path) and 'MTD_TL' in s:
            result.append(s_path[0:-10])
            #result.append(s_path[10:-10])


if __name__ == "__main__":
    findfiles(path,result)
    for i in range(len(result)):
       # print("[{} ,".format(i)+"'"+result[i]+"\']")


       # print(result[i][0:-44]) ### that for get "S2A" or "S2B"
        with open("/home/bjiang/software/acolite-master/image_202107bow.txt",'a') as fff: # creat txt named with "image_202107bow" for 202107bow site
             #fff.write("\n")
             fff.write(result[i][0:-44] + "\n")    # put the direction of path in txt
                            # change the line 
             #fff.write("contains")
             fff.close()   # close it
